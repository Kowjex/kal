<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "order".
 *
 * @property int $id
 * @property int $user_id Кто делает заявку
 * @property string $datatime_start
 * @property string $equipment
 * @property int $type_id тип неисправности
 * @property string $description
 * @property int $orderstatus_id
 * @property int|null $responsible_id ответственный за выполнение работ
 * @property int $priority_id
 * @property string $datatime_end
 * @property string|null $comment
 *
 * @property Orderstatus $orderstatus
 * @property Orderuser[] $orderusers
 * @property Priority $priority
 * @property User $responsible
 * @property Type $type
 * @property User $user
 */
class Order extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'order';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'user_id', 'datatime_start', 'equipment', 'type_id', 'description', 'datatime_end'], 'required'],
            [['id', 'user_id', 'type_id', 'orderstatus_id', 'responsible_id', 'priority_id'], 'integer'],
            [['datatime_start', 'datatime_end'], 'safe'],
            [['description'], 'string'],
            [['equipment', 'comment'], 'string', 'max' => 255],
            [['id'], 'unique'],
            [['orderstatus_id'], 'exist', 'skipOnError' => true, 'targetClass' => Orderstatus::class, 'targetAttribute' => ['orderstatus_id' => 'id']],
            [['responsible_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['responsible_id' => 'id']],
            [['type_id'], 'exist', 'skipOnError' => true, 'targetClass' => Type::class, 'targetAttribute' => ['type_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['user_id' => 'id']],
            [['priority_id'], 'exist', 'skipOnError' => true, 'targetClass' => Priority::class, 'targetAttribute' => ['priority_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'Заказчик',
            'datatime_start' => 'Дата начала',
            'equipment' => 'Оборудование',
            'type_id' => 'Тип поломки',
            'description' => 'Описание',
            'orderstatus_id' => 'Статус заказа',
            'responsible_id' => 'Ответственный сотрудник',
            'priority_id' => 'Приоритет',
            'datatime_end' => 'Дата конца',
            'comment' => 'Комментарий сотрудника',
        ];
    }

    /**
     * Gets query for [[Orderstatus]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOrderstatus()
    {
        return $this->hasOne(Orderstatus::class, ['id' => 'orderstatus_id']);
    }

    /**
     * Gets query for [[Orderusers]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOrderusers()
    {
        return $this->hasMany(Orderuser::class, ['order_id' => 'id']);
    }

    /**
     * Gets query for [[Priority]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPriority()
    {
        return $this->hasOne(Priority::class, ['id' => 'priority_id']);
    }

    /**
     * Gets query for [[Responsible]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getResponsible()
    {
        return $this->hasOne(User::class, ['id' => 'responsible_id']);
    }

    /**
     * Gets query for [[Type]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getType()
    {
        return $this->hasOne(Type::class, ['id' => 'type_id']);
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }
}
