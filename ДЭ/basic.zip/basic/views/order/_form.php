<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\Order $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="order-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'user_id')->textInput() ?>

    <?= $form->field($model, 'equipment')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'type_id')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\Type::find()
        ->all(), 'id', 'name')) ?>

    <?= $form->field($model, 'priority_id')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\Priority::find()
        ->all(), 'id', 'name')) ?>

    <?= $form->field($model, 'description')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'orderstatus_id')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\Orderstatus::find()
        ->all(), 'id', 'name')) ?>


    <?= $form->field($model, 'responsible_id')->dropDownList(\yii\helpers\ArrayHelper::map(\app\models\User::find()->where(['role_id' => '2'])->all(), 'id', 'fio'))?>

    <?php if (!$model->isNewRecord): ?>
        <?= $form->field($model, 'comment')->textarea(['rows' => 6]) ?>
    <?php endif; ?>

    <?= $form->field($model, 'datatime_end')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
